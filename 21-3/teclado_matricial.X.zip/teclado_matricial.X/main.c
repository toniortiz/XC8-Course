#include <xc.h>
#include "config.h"
#include "lcd.h"
#include <inttypes.h>
#include <stdio.h>

#define _XTAL_FREQ 8000000

volatile uint8_t tecla = 0;
volatile uint16_t valor1 = 0;
volatile uint16_t valor2 = 0;

typedef enum {
    INGRESANDO_VALOR1 = 0,
    INGRESANDO_VALOR2
} Estado;

volatile Estado edo = INGRESANDO_VALOR1;

uint8_t leer_tecla() {
    uint8_t tecla = 0;

    switch (PORTE) {
        case 0: tecla = '1';
            break;
        case 1: tecla = '2';
            break;
        case 2: tecla = '3';
            break;
        case 3: tecla = 'A';
            break;
        case 4: tecla = '4';
            break;
        case 5: tecla = '5';
            break;
        case 6: tecla = '6';
            break;
        case 7: tecla = 'B';
            break;
        case 8: tecla = '7';
            break;
        case 9: tecla = '8';
            break;
        case 10: tecla = '9';
            break;
        case 11: tecla = 'C';
            break;
        case 12: tecla = '*';
            break;
        case 13: tecla = '0';
            break;
        case 14: tecla = '#';
            break;
        case 15: tecla = 'D';
            break;
        default: break;
    }

    return tecla;
}

void int_ext0() {
    if (INTCONbits.INT0IF == 1) {
        tecla = leer_tecla();

        if (tecla == '*' || tecla == '#') {
            lcd_clear();
            lcd_return_home();

        } else if (tecla >= '0' && tecla <= '9') {
            char buf[5];

            if (edo == INGRESANDO_VALOR1) {
                valor1 = valor1 * 10 + (tecla - 48);
                sprintf(buf, "%u", valor1);
            } else if (edo == INGRESANDO_VALOR2) {
                valor2 = valor2 * 10 + (tecla - 48);
                sprintf(buf, "%u", valor2);
            }

            lcd_clear();
            lcd_putrs_at(0, 0, buf);

        } else if (tecla == 'A') {
            lcd_clear();
            lcd_return_home();
            edo = INGRESANDO_VALOR2;

        } else if (tecla == 'D') {
            edo = INGRESANDO_VALOR1;
            lcd_clear();
            uint16_t suma = valor1 + valor2;
            char buf[20];
            sprintf(buf, "%u + %u = %u", valor1, valor2, suma);
            lcd_putrs_at(0, 0, buf);
            valor1 = 0;
            valor2 = 0;
        }

        INTCONbits.INT0IF = 0;
    }
}

void __interrupt() interrupts() {
    int_ext0();
}

void main(void) {
    OSCCON = 0x76;
    ADCON1 = 0x0F;

    // Configurar int ext 0
    TRISBbits.RB0 = 1;
    INTCONbits.INT0IE = 1;
    INTCONbits.INT0IF = 0;
    INTCON2bits.INTEDG0 = 1;

    INTCONbits.GIE = 1;

    lcd_t lcd = {&PORTD,
        2, // RS
        3, // E
        4, // D4
        5, // D5
        6, // D6
        7}; // D7

    lcd_init(lcd);

    lcd_clear();
    lcd_set_cursor(0, 0);
    lcd_putrs("Hola");

    TRISE = 0b1111;

    while (1) {

    }

    return;
}

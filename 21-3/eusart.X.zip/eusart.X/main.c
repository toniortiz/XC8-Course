#include <xc.h>
#include <string.h>
#include "config.h"
#include <stdio.h>

#define _XTAL_FREQ 8000000

void enviar(const char* cadena, const size_t n) {
    size_t i;
    for (i = 0; i < n; i++) {
        const char caracter = cadena[i];

        // Esperar a que el TSR est� vacio
        while (!TXSTAbits.TRMT);
        TXREG = caracter;
    }
}

void main(void) {
    OSCCON = 0x76;
    ADCON1 = 0x0F;

    // Configuracion EUSART
    TRISCbits.RC6 = 1;
    TRISCbits.RC7 = 1;

    TXSTAbits.BRGH = 1; // Alta velocidad
    TXSTAbits.SYNC = 0; // Asincrono
    TXSTAbits.TXEN = 1; // Habilitar envio de datos
    TXSTAbits.TX9 = 0; // 8 bits de transmision
    RCSTAbits.CREN = 1; // habilitar recepcion de datos
    RCSTAbits.RX9 = 0; // 8 bits de recepcion
    RCSTAbits.SPEN = 1; // habilitar puerto serie
    BAUDCONbits.BRG16 = 0; // BGR en modo de 8 bits
    SPBRG = 51;

    // Configuracion de las interrupciones

    TRISAbits.RA0 = 0;
    LATAbits.LA0 = 0;

    char cadena[20];
    float temperatura = 0.0f;

    while (1) {
        sprintf(cadena, "@%.2f/%d\r\n", temperatura, LATAbits.LA0);
        enviar(cadena, strlen(cadena));

        temperatura += 2.5;
        LATAbits.LA0 = ~LATAbits.LA0;

        __delay_ms(1000);
    }

    return;
}
